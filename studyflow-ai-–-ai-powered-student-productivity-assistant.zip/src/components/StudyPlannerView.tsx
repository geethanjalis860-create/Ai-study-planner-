import React, { useState } from 'react';
import { useStudy } from '../context/StudyContext';
import { StudyPlanDay, StudyPlanTask } from '../types';
import {
  CalendarDays,
  Clock,
  Sparkles,
  CheckCircle2,
  Circle,
  RotateCw,
  Plus,
  BookOpen,
  Calendar,
  Layers,
  ChevronRight,
  Flame,
} from 'lucide-react';

export const StudyPlannerView: React.FC = () => {
  const {
    subjects,
    topics,
    studyPlan,
    setStudyPlan,
    addSubject,
    setCurrentView,
  } = useStudy();

  const [dailyHours, setDailyHours] = useState(3.5);
  const [examDaysRemaining, setExamDaysRemaining] = useState(5);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);

  // Subject quick add modal state
  const [showAddSubjectModal, setShowAddSubjectModal] = useState(false);
  const [newSubjName, setNewSubjName] = useState('');
  const [newSubjCode, setNewSubjCode] = useState('');
  const [newSubjDate, setNewSubjDate] = useState('2026-10-20');

  const weakTopicTitles = topics.filter((t) => t.isWeakArea).map((t) => t.title);

  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/study/generate-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subjects,
          dailyStudyHours: dailyHours,
          daysUntilFirstExam: examDaysRemaining,
          weakTopics: weakTopicTitles,
        }),
      });

      const data = await res.json();
      if (data.success && data.plan?.days) {
        setStudyPlan(data.plan.days);
        setSelectedDayIndex(0);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleTaskCompleted = (dayIndex: number, taskId: string) => {
    const updated = [...studyPlan];
    const targetDay = updated[dayIndex];
    if (!targetDay) return;

    targetDay.tasks = targetDay.tasks.map((task) => {
      if (task.id === taskId) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });

    setStudyPlan(updated);
  };

  const handleAddSubjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubjName.trim() || !newSubjCode.trim()) return;

    addSubject({
      name: newSubjName,
      code: newSubjCode,
      examDate: newSubjDate,
      color: 'indigo',
    });

    setNewSubjName('');
    setNewSubjCode('');
    setShowAddSubjectModal(false);
  };

  const activeDay = studyPlan[selectedDayIndex] || studyPlan[0];

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-indigo-400" />
            Smart AI Study Planner
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Personalized, milestone-driven daily timetable balancing upcoming exam deadlines and weak areas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddSubjectModal(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4 text-indigo-400" />
            <span>Add Exam Subject</span>
          </button>
        </div>
      </div>

      {/* Control Configuration Bar */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          {/* Daily Study Hours Slider */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase text-slate-400">
                Daily Available Hours
              </label>
              <span className="text-sm font-black text-indigo-400">{dailyHours} hrs / day</span>
            </div>
            <input
              type="range"
              min="1"
              max="8"
              step="0.5"
              value={dailyHours}
              onChange={(e) => setDailyHours(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <span className="text-[11px] text-slate-500 block mt-1">
              Broken into targeted 30-45 minute focus sessions
            </span>
          </div>

          {/* Exam Days Horizon */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase text-slate-400">
                Plan Horizon
              </label>
              <span className="text-sm font-black text-amber-400">{examDaysRemaining} Days</span>
            </div>
            <input
              type="range"
              min="3"
              max="14"
              step="1"
              value={examDaysRemaining}
              onChange={(e) => setExamDaysRemaining(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <span className="text-[11px] text-slate-500 block mt-1">
              Priority adjusted based on nearest exam date
            </span>
          </div>

          {/* Generate Button */}
          <div className="flex flex-col justify-end">
            <button
              onClick={handleGeneratePlan}
              disabled={isGenerating}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-violet-600 to-amber-500 hover:from-indigo-500 hover:via-violet-500 hover:to-amber-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60"
            >
              <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : 'text-amber-300'}`} />
              <span>{isGenerating ? 'Synthesizing Adaptive Plan...' : 'Generate AI Study Schedule'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Days & Schedule Presentation */}
      {studyPlan.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Day Tabs */}
          <div className="lg:col-span-1 space-y-2.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Schedule Timeline ({studyPlan.length} Days)
            </h3>
            {studyPlan.map((day, idx) => {
              const isSelected = selectedDayIndex === idx;
              const completedCount = day.tasks.filter((t) => t.completed).length;
              return (
                <div
                  key={idx}
                  onClick={() => setSelectedDayIndex(idx)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-950/50 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold">{day.date} - {day.dayName}</span>
                    {day.isToday && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] uppercase font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Today
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-1 line-clamp-1">
                    {day.focusSummary}
                  </span>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-500">
                    <span>{day.tasks.length} sessions</span>
                    <span>{completedCount}/{day.tasks.length} done</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Daily Detailed Session Schedule */}
          <div className="lg:col-span-3 space-y-4">
            {activeDay && (
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-black text-white">
                        {activeDay.date} • {activeDay.dayName}
                      </h3>
                      {activeDay.isToday && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Active Focus Day
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-indigo-400 font-medium mt-0.5">
                      {activeDay.focusSummary}
                    </p>
                  </div>
                  <div className="text-xs font-bold text-slate-400 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 self-start">
                    Target: {activeDay.totalHours} Hours
                  </div>
                </div>

                {/* Session Task Cards */}
                <div className="space-y-3 pt-2">
                  {activeDay.tasks.map((task) => (
                    <div
                      key={task.id}
                      className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                        task.completed
                          ? 'bg-emerald-950/15 border-emerald-500/40 opacity-75'
                          : 'bg-slate-800/60 border-slate-700/60 hover:border-slate-600'
                      }`}
                    >
                      <button
                        onClick={() => toggleTaskCompleted(selectedDayIndex, task.id)}
                        className="mt-0.5 text-slate-500 hover:text-emerald-400 transition-colors cursor-pointer shrink-0"
                      >
                        {task.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-400/20" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-bold text-indigo-400">
                              {task.subjectName}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                                task.type === 'concept'
                                  ? 'bg-blue-500/20 text-blue-300'
                                  : task.type === 'practice'
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : task.type === 'quiz'
                                  ? 'bg-violet-500/20 text-violet-300'
                                  : 'bg-teal-500/20 text-teal-300'
                              }`}
                            >
                              {task.type}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                            <Clock className="w-3.5 h-3.5 text-slate-500" />
                            <span>{task.timeSlot}</span>
                            <span className="text-amber-400">({task.durationMinutes}m)</span>
                          </div>
                        </div>

                        <h4
                          className={`text-sm font-bold mt-1 ${
                            task.completed ? 'line-through text-slate-400' : 'text-white'
                          }`}
                        >
                          {task.topicTitle}
                        </h4>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="p-12 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-4">
          <Calendar className="w-12 h-12 text-indigo-400 mx-auto" />
          <h3 className="text-lg font-bold text-white">No Active Study Plan Generated Yet</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Click &quot;Generate AI Study Schedule&quot; above to have StudyFlow AI synthesize a balanced daily timetable tailored to your upcoming exam dates and weak topics.
          </p>
          <button
            onClick={handleGeneratePlan}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Generate Plan Now
          </button>
        </div>
      )}

      {/* Add Subject Modal */}
      {showAddSubjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4 text-white">
            <h3 className="text-base font-bold">Add New Exam Subject</h3>
            <form onSubmit={handleAddSubjectSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Subject Code</label>
                <input
                  type="text"
                  placeholder="e.g. CS402"
                  value={newSubjCode}
                  onChange={(e) => setNewSubjCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Subject Name</label>
                <input
                  type="text"
                  placeholder="e.g. Distributed Systems & Cloud"
                  value={newSubjName}
                  onChange={(e) => setNewSubjName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Exam Date</label>
                <input
                  type="date"
                  value={newSubjDate}
                  onChange={(e) => setNewSubjDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddSubjectModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500"
                >
                  Save Subject
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
