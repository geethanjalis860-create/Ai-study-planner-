import React from 'react';
import { useStudy } from '../context/StudyContext';
import {
  Play,
  Pause,
  CheckCircle2,
  X,
  Sparkles,
  Trophy,
  GraduationCap,
  BrainCircuit,
  Maximize2,
} from 'lucide-react';

export const ActiveStudySessionModal: React.FC = () => {
  const {
    activeSession,
    toggleSessionTimer,
    markSessionStepDone,
    finishStudySession,
    cancelStudySession,
    setCurrentView,
  } = useStudy();

  if (!activeSession) return null;

  const totalTargetSec = activeSession.totalTargetSeconds;
  const elapsedSec = activeSession.elapsedSeconds;
  const remainingSec = Math.max(0, totalTargetSec - elapsedSec);

  const minutesRemaining = Math.floor(remainingSec / 60);
  const secondsRemaining = remainingSec % 60;
  const progressPercent = Math.min(100, Math.round((elapsedSec / totalTargetSec) * 100));

  const pad = (n: number) => n.toString().padStart(2, '0');

  const rec = activeSession.recommendation;
  const allStepsDone =
    rec.steps.length > 0 &&
    rec.steps.every((_, idx) => activeSession.completedStepIndices.includes(idx));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-lg overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl overflow-hidden text-slate-100 my-8">
        {/* Top Header */}
        <div className="p-6 border-b border-slate-800 bg-gradient-to-b from-indigo-950/40 to-slate-900">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-400">
                Live Study Sprint in Progress
              </span>
            </div>
            <button
              onClick={cancelStudySession}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              title="Close Session"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-3">
            <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
              {rec.subjectName}
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
              {rec.topicTitle}
            </h3>
          </div>
        </div>

        {/* Big Aesthetic Pomodoro Timer Display */}
        <div className="p-6 flex flex-col items-center justify-center border-b border-slate-800 bg-slate-950/40">
          <div className="relative flex items-center justify-center w-48 h-48 sm:w-56 sm:h-56">
            {/* Circular Ring SVG */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="50%"
                cy="50%"
                r="42%"
                className="text-slate-800 stroke-current"
                strokeWidth="8"
                fill="transparent"
              />
              <circle
                cx="50%"
                cy="50%"
                r="42%"
                className="text-indigo-500 stroke-current transition-all duration-1000 ease-linear"
                strokeWidth="8"
                strokeDasharray="264"
                strokeDashoffset={264 - (264 * progressPercent) / 100}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-4xl sm:text-5xl font-mono font-black text-white tracking-tight">
                {pad(minutesRemaining)}:{pad(secondsRemaining)}
              </span>
              <span className="text-xs text-slate-400 font-medium mt-1">
                {activeSession.isRunning ? 'Focus Mode Active' : 'Timer Paused'}
              </span>
              <span className="text-[11px] font-semibold text-indigo-400 mt-1">
                {progressPercent}% Complete
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3 mt-4">
            <button
              onClick={toggleSessionTimer}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-lg transition-all cursor-pointer ${
                activeSession.isRunning
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                  : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/30'
              }`}
            >
              {activeSession.isRunning ? (
                <>
                  <Pause className="w-4 h-4 fill-amber-300" />
                  <span>Pause Timer</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Resume Timer</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                setCurrentView('tutor');
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <GraduationCap className="w-4 h-4 text-indigo-400" />
              <span>Ask Doubt</span>
            </button>

            <button
              onClick={() => {
                setCurrentView('quiz');
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <BrainCircuit className="w-4 h-4 text-violet-400" />
              <span>Quick Quiz</span>
            </button>
          </div>
        </div>

        {/* Step Checklist */}
        <div className="p-6 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Sprint Action Checklist ({activeSession.completedStepIndices.length}/{rec.steps.length})
            </h4>
            <span className="text-xs text-amber-400 font-medium">Click to mark complete</span>
          </div>

          <div className="space-y-2.5">
            {rec.steps.map((step, idx) => {
              const isDone = activeSession.completedStepIndices.includes(idx);
              return (
                <div
                  key={idx}
                  onClick={() => markSessionStepDone(idx)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                    isDone
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                      : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600 text-slate-200'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-400/20" />
                    ) : (
                      <div className="w-5 h-5 rounded-md border-2 border-slate-500 flex items-center justify-center text-[10px] font-bold text-slate-400">
                        {step.stepNumber}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`text-sm font-bold ${isDone ? 'line-through text-slate-400' : 'text-white'}`}>
                        {step.title}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-900 text-slate-300 border border-slate-700 shrink-0">
                        {step.minutes}m
                      </span>
                    </div>
                    <p className={`text-xs mt-0.5 ${isDone ? 'text-slate-500' : 'text-slate-400'}`}>
                      {step.instruction}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Completion Footer */}
        <div className="p-5 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-400">
            {allStepsDone ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                All steps finished! Ready to complete.
              </span>
            ) : (
              <span>Finish when done to record minutes & boost streak</span>
            )}
          </div>

          <button
            onClick={finishStudySession}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <Trophy className="w-4 h-4" />
            <span>Finish & Record Progress</span>
          </button>
        </div>
      </div>
    </div>
  );
};
