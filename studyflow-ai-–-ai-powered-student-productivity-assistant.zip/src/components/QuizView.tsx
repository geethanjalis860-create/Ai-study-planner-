import React, { useState } from 'react';
import { useStudy } from '../context/StudyContext';
import { QuizQuestion, QuizResult } from '../types';
import {
  BrainCircuit,
  Sparkles,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Trophy,
  ArrowRight,
  BookOpen,
  Award,
} from 'lucide-react';

export const QuizView: React.FC = () => {
  const {
    topics,
    materials,
    recordQuizResult,
    quizHistory,
    setCurrentView,
  } = useStudy();

  const [activeStep, setActiveStep] = useState<'config' | 'taking' | 'results'>('config');

  // Config options
  const [selectedTopicId, setSelectedTopicId] = useState<string>(topics[0]?.id || '');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Taking quiz state
  const [currentQuestions, setCurrentQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);
  const [quizTimer, setQuizTimer] = useState<any>(null);

  // Results state
  const [lastResult, setLastResult] = useState<QuizResult | null>(quizHistory[0] || null);

  const selectedTopic = topics.find((t) => t.id === selectedTopicId) || topics[0];
  const matchingMaterial = materials.find((m) => m.subjectId === selectedTopic?.subjectId);

  const handleStartQuiz = async () => {
    if (!selectedTopic) return;

    setIsGenerating(true);
    try {
      const res = await fetch('/api/study/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: selectedTopic.title,
          subject: selectedTopic.subjectName,
          notesContext: matchingMaterial?.rawText || selectedTopic.summary,
          difficulty,
          count: questionCount,
        }),
      });

      const data = await res.json();
      if (!data.success || !data.quiz?.questions?.length) {
        throw new Error(data.error || 'Failed to generate quiz');
      }

      setCurrentQuestions(data.quiz.questions);
      setCurrentQuestionIndex(0);
      setUserAnswers({});
      setSecondsElapsed(0);
      setActiveStep('taking');

      // Start elapsed timer
      const interval = setInterval(() => {
        setSecondsElapsed((prev) => prev + 1);
      }, 1000);
      setQuizTimer(interval);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectOption = (questionId: string, option: string) => {
    setUserAnswers((prev) => ({
      ...prev,
      [questionId]: option,
    }));
  };

  const handleSubmitQuiz = async () => {
    if (quizTimer) clearInterval(quizTimer);

    try {
      const res = await fetch('/api/study/evaluate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questions: currentQuestions,
          userAnswers,
          title: `${selectedTopic?.title || 'Subject'} Diagnostic Quiz`,
          subjectName: selectedTopic?.subjectName || 'Computer Science',
        }),
      });

      const data = await res.json();
      if (data.success && data.result) {
        setLastResult(data.result);
        recordQuizResult(data.result);
        setActiveStep('results');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const activeQuestion = currentQuestions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === currentQuestions.length - 1;

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <BrainCircuit className="w-6 h-6 text-indigo-400" />
            AI Diagnostic Quiz Arena
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Generate customized MCQs and descriptive tests. Evaluates scoring, flags weak topics, and dynamically updates your study plan.
          </p>
        </div>

        {activeStep !== 'config' && (
          <button
            onClick={() => setActiveStep('config')}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer self-start"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>New Quiz Config</span>
          </button>
        )}
      </div>

      {/* ---------------------------------------------------- */}
      {/* STEP 1: CONFIGURATION */}
      {/* ---------------------------------------------------- */}
      {activeStep === 'config' && (
        <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 text-violet-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Configure AI Diagnostic Test</h3>
              <p className="text-xs text-slate-400">
                AI designs questions directly based on notes and common exam pitfalls.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Topic Select */}
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 mb-1.5 block">
                Target Topic / Subject Module
              </label>
              <select
                value={selectedTopicId}
                onChange={(e) => setSelectedTopicId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {topics.map((t) => (
                  <option key={t.id} value={t.id}>
                    [{t.subjectName}] {t.title} {t.isWeakArea ? '⚠️ (Weak Area)' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Difficulty Pills */}
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 mb-1.5 block">
                Difficulty Level
              </label>
              <div className="grid grid-cols-3 gap-3">
                {(['easy', 'medium', 'hard'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setDifficulty(lvl)}
                    className={`py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider border transition-all cursor-pointer ${
                      difficulty === lvl
                        ? 'bg-violet-950/60 border-violet-500 text-violet-200 ring-1 ring-violet-500/40'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            {/* Question count */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase text-slate-400">
                  Question Count
                </label>
                <span className="text-xs font-black text-violet-400">{questionCount} Questions</span>
              </div>
              <input
                type="range"
                min="3"
                max="10"
                step="1"
                value={questionCount}
                onChange={(e) => setQuestionCount(parseInt(e.target.value))}
                className="w-full accent-violet-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Start Button */}
          <button
            onClick={handleStartQuiz}
            disabled={isGenerating}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-violet-600 via-indigo-600 to-amber-500 hover:from-violet-500 hover:via-indigo-500 hover:to-amber-400 text-white font-bold text-sm shadow-lg shadow-violet-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60"
          >
            {isGenerating ? (
              <>
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Generating Exam Diagnostic with Gemini...</span>
              </>
            ) : (
              <>
                <BrainCircuit className="w-4 h-4" />
                <span>Launch Diagnostic Quiz ({questionCount} Qs)</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* STEP 2: ACTIVE QUIZ RUNNER */}
      {/* ---------------------------------------------------- */}
      {activeStep === 'taking' && activeQuestion && (
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Top Progress & Timer Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                Question {currentQuestionIndex + 1} of {currentQuestions.length}
              </span>
              <span className="text-xs text-slate-500">•</span>
              <span className="text-xs text-slate-400">{activeQuestion.topic}</span>
            </div>

            <div className="flex items-center gap-1.5 font-mono text-xs text-amber-400 font-bold bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30">
              <Clock className="w-3.5 h-3.5" />
              <span>
                {Math.floor(secondsElapsed / 60)}:{(secondsElapsed % 60).toString().padStart(2, '0')}
              </span>
            </div>
          </div>

          {/* Question Box */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
            <h3 className="text-base sm:text-lg font-bold text-white leading-relaxed">
              {activeQuestion.question}
            </h3>

            {/* MCQ Options */}
            {activeQuestion.type === 'mcq' && activeQuestion.options && (
              <div className="space-y-3">
                {activeQuestion.options.map((opt, idx) => {
                  const isSelected = userAnswers[activeQuestion.id] === opt;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectOption(activeQuestion.id, opt)}
                      className={`w-full p-4 rounded-xl text-left border transition-all cursor-pointer flex items-center gap-3 text-xs sm:text-sm ${
                        isSelected
                          ? 'bg-indigo-950/60 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                          : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                          isSelected ? 'border-indigo-400 bg-indigo-500 text-white' : 'border-slate-600'
                        }`}
                      >
                        {String.fromCharCode(65 + idx)}
                      </div>
                      <span className="flex-1">{opt}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Descriptive Answer Box */}
            {activeQuestion.type === 'descriptive' && (
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">
                  Write your conceptual answer:
                </label>
                <textarea
                  rows={4}
                  placeholder="Explain the concept concisely as required in exam..."
                  value={userAnswers[activeQuestion.id] || ''}
                  onChange={(e) => handleSelectOption(activeQuestion.id, e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex((prev) => prev - 1)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 disabled:opacity-40 cursor-pointer"
              >
                Previous
              </button>

              {isLastQuestion ? (
                <button
                  type="button"
                  onClick={handleSubmitQuiz}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submit & Diagnose Performance</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setCurrentQuestionIndex((prev) => prev + 1)}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Next Question</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* STEP 3: RESULTS & WEAK AREA DIAGNOSTIC */}
      {/* ---------------------------------------------------- */}
      {activeStep === 'results' && lastResult && (
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Score Header Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl text-center space-y-4">
            <div
              className={`w-16 h-16 rounded-2xl mx-auto flex items-center justify-center text-3xl shadow-lg ${
                lastResult.percentage >= 70
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
              }`}
            >
              {lastResult.percentage >= 70 ? <Trophy className="w-8 h-8" /> : <AlertTriangle className="w-8 h-8" />}
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Diagnostic Results • {lastResult.subjectName}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-white mt-1">
                Score: {lastResult.score} / {lastResult.maxScore} ({lastResult.percentage}%)
              </h3>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
              {lastResult.recommendationNote}
            </p>

            {/* Weak topics tag alerts */}
            {lastResult.weakTopics.length > 0 && (
              <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-500/30 text-left space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  Identified Weak Topics (Automatically Added to Priorities & Study Plan):
                </span>
                <div className="flex flex-wrap gap-2">
                  {lastResult.weakTopics.map((wt, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40"
                    >
                      {wt}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Next Actions */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setCurrentView('priority')}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                View Updated Task Priorities
              </button>
              <button
                onClick={() => setActiveStep('config')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
              >
                Retake or Try Another Topic
              </button>
            </div>
          </div>

          {/* Detailed Question Review */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              Question-by-Question Diagnostic Review:
            </h4>

            {lastResult.questions.map((q, idx) => (
              <div
                key={idx}
                className={`p-5 rounded-2xl border space-y-3 ${
                  q.isCorrect
                    ? 'bg-emerald-950/10 border-emerald-500/30'
                    : 'bg-rose-950/15 border-rose-500/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">Question {idx + 1}</span>
                  <span
                    className={`flex items-center gap-1 text-xs font-bold ${
                      q.isCorrect ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {q.isCorrect ? (
                      <>
                        <CheckCircle2 className="w-4 h-4" /> Correct (+{q.marks} marks)
                      </>
                    ) : (
                      <>
                        <XCircle className="w-4 h-4" /> Incorrect (0 marks)
                      </>
                    )}
                  </span>
                </div>

                <p className="text-sm font-bold text-white">{q.question}</p>

                <div className="text-xs space-y-1">
                  {q.userAnswer && (
                    <div className="text-slate-400">
                      Your Answer: <span className="font-semibold text-slate-200">{q.userAnswer}</span>
                    </div>
                  )}
                  <div className="text-emerald-400">
                    Correct Answer: <span className="font-semibold">{q.correctAnswer}</span>
                  </div>
                </div>

                {q.explanation && (
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-700/60 text-xs text-slate-300 leading-relaxed">
                    <span className="font-bold text-amber-300 block mb-0.5">Explanation:</span>
                    {q.explanation}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
