import React from 'react';
import { useStudy } from '../context/StudyContext';
import {
  Zap,
  Sparkles,
  Flame,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Play,
  BookOpen,
  GraduationCap,
  CalendarDays,
  BrainCircuit,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    subjects,
    topics,
    stats,
    recommendation,
    setIsRecommendationModalOpen,
    startGuidedSession,
    setCurrentView,
    toggleTopicCompleted,
    calculateTopicPriority,
    quizHistory,
  } = useStudy();

  // Top 4 prioritized uncompleted topics
  const uncompletedTopics = topics.filter((t) => !t.completed);
  const prioritizedTopics = [...uncompletedTopics].sort((a, b) => {
    const pA = calculateTopicPriority(a).score;
    const pB = calculateTopicPriority(b).score;
    return pB - pA;
  }).slice(0, 4);

  // Latest quiz
  const latestQuiz = quizHistory[0];

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* ---------------------------------------------------- */}
      {/* 1. HERO BANNER: "WHAT SHOULD I DO NOW?" */}
      {/* ---------------------------------------------------- */}
      {recommendation && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 border border-indigo-500/40 shadow-2xl p-6 sm:p-8">
          {/* Decorative glowing gradient backdrop */}
          <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-gradient-to-br from-amber-500/10 via-indigo-500/20 to-rose-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-3 max-w-2xl">
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5 shadow-sm">
                  <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  What Should I Do Now?
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-rose-400" />
                  High Urgency
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {recommendation.subjectName} • Exam in {recommendation.daysLeft} days
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-tight">
                {recommendation.headline}
              </h2>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {recommendation.reason}
              </p>

              {/* Step pills preview */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {recommendation.steps.map((s, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-200"
                  >
                    <span className="w-4 h-4 rounded-full bg-indigo-500/30 text-indigo-300 flex items-center justify-center text-[10px] font-bold">
                      {s.stepNumber}
                    </span>
                    <span>{s.title}</span>
                    <span className="text-amber-400 font-semibold text-[10px]">({s.minutes}m)</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row lg:flex-col items-stretch gap-3 shrink-0">
              <button
                onClick={() => startGuidedSession(recommendation)}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:from-amber-400 hover:via-rose-400 hover:to-indigo-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2.5 transition-all hover:scale-[1.03] active:scale-[0.98] cursor-pointer"
              >
                <Play className="w-5 h-5 fill-white" />
                <span>Start Guided Sprint ({recommendation.totalMinutes}m)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsRecommendationModalOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Inspect Recommendation Details</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 2. STATS & METRICS ROW */}
      {/* ---------------------------------------------------- */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Overall Readiness */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Exam Readiness
            </span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.overallReadinessPercentage}%
            </span>
            <span className="text-xs text-emerald-400 font-semibold">+8% this week</span>
          </div>
          {/* Progress bar */}
          <div className="mt-3 w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-700"
              style={{ width: `${stats.overallReadinessPercentage}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Study Streak */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Study Streak
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Flame className="w-4 h-4 fill-amber-400" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.streakDays}
            </span>
            <span className="text-xs text-amber-400 font-semibold">Days Active 🔥</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Keep it going today to reach 6 days!
          </p>
        </div>

        {/* Metric 3: Hours Studied */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Time Invested
            </span>
            <div className="p-2 rounded-xl bg-violet-500/10 text-violet-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {(stats.totalMinutesStudied / 60).toFixed(1)}
            </span>
            <span className="text-xs text-slate-400 font-medium">Hours Studied</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {stats.completedTopicsCount} of {stats.totalTopicsCount} topics completed
          </p>
        </div>

        {/* Metric 4: Weak Areas */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Weak Areas
            </span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.weakTopicsCount}
            </span>
            <span className="text-xs text-rose-400 font-semibold">Flagged Topics</span>
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">Quiz score &lt; 60%</span>
            <button
              onClick={() => setCurrentView('priority')}
              className="text-[11px] text-indigo-400 font-semibold hover:underline"
            >
              Fix now →
            </button>
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------- */}
      {/* 3. CORE TWO COLUMNS: UPCOMING EXAMS & SMART PRIORITIES */}
      {/* ---------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Smart Prioritized Tasks (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                Smart Prioritized Next Tasks
              </h3>
              <p className="text-xs text-slate-400">
                Ranked dynamically by Exam Urgency, Syllabus Weightage, and Quiz Weak Areas.
              </p>
            </div>
            <button
              onClick={() => setCurrentView('priority')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
            >
              <span>View All Tasks</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {prioritizedTopics.map((topic) => {
              const { score, badge, reason } = calculateTopicPriority(topic);
              return (
                <div
                  key={topic.id}
                  className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                >
                  <div className="flex items-start gap-3.5 flex-1 min-w-0">
                    <button
                      onClick={() => toggleTopicCompleted(topic.id)}
                      className="mt-1 text-slate-600 hover:text-emerald-400 transition-colors cursor-pointer shrink-0"
                      title="Mark as completed"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[11px] font-semibold text-indigo-400">
                          {topic.subjectName}
                        </span>
                        {badge === 'critical' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30">
                            Critical Priority ({score})
                          </span>
                        )}
                        {badge === 'high' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            High Priority ({score})
                          </span>
                        )}
                        {topic.isWeakArea && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950/40 text-rose-400 border border-rose-800/40">
                            Weak Spot ({topic.mastery}%)
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm sm:text-base font-bold text-white mt-1 truncate">
                        {topic.title}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{reason}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <button
                      onClick={() => {
                        setCurrentView('tutor');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Ask Tutor</span>
                    </button>
                    <button
                      onClick={() => {
                        setCurrentView('quiz');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <BrainCircuit className="w-3.5 h-3.5" />
                      <span>Take Quiz</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Upcoming Exams & Recent Quiz (1 Col) */}
        <div className="space-y-6">
          {/* Upcoming Exams Countdown Cards */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-amber-400" />
                Upcoming Exams
              </h3>
              <button
                onClick={() => setCurrentView('planner')}
                className="text-xs text-indigo-400 font-semibold hover:underline"
              >
                Planner →
              </button>
            </div>

            <div className="space-y-3">
              {subjects.map((subj) => {
                const diffMs = new Date(subj.examDate).getTime() - new Date().getTime();
                const daysLeft = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
                const isUrgent = daysLeft <= 5;

                return (
                  <div
                    key={subj.id}
                    className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">{subj.code}</span>
                        <span className="text-[11px] text-slate-400 truncate max-w-[130px]">
                          {subj.name}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {subj.examDate}
                      </span>
                    </div>

                    <div className="text-right shrink-0">
                      <span
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold block ${
                          isUrgent
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                            : 'bg-slate-700 text-slate-200'
                        }`}
                      >
                        {daysLeft} days left
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Latest Quiz Performance Report */}
          {latestQuiz && (
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <BrainCircuit className="w-4 h-4 text-violet-400" />
                  Recent Quiz Diagnostic
                </h3>
                <span className="text-xs text-slate-400">{latestQuiz.subjectName}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">{latestQuiz.title}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-xs font-black ${
                      latestQuiz.percentage >= 70
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {latestQuiz.percentage}% ({latestQuiz.score}/{latestQuiz.maxScore})
                  </span>
                </div>

                {latestQuiz.weakTopics.length > 0 && (
                  <div className="pt-1">
                    <span className="text-[11px] font-bold text-rose-400 block mb-1">
                      Identified Weak Topics:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {latestQuiz.weakTopics.map((wt, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-950/40 text-rose-300 border border-rose-800/40"
                        >
                          {wt}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <button
                onClick={() => setCurrentView('quiz')}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>Launch New AI Quiz</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ---------------------------------------------------- */}
      {/* 4. FAST ACTION TILES: "Upload -> Understand -> Plan -> Learn -> Test" */}
      {/* ---------------------------------------------------- */}
      <div className="pt-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
          StudyFlow Core Flow (Upload → Understand → Plan → Learn → Test → Recommend)
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div
            onClick={() => setCurrentView('materials')}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/40 hover:bg-slate-800/70 transition-all cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform mb-3">
              <BookOpen className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-indigo-300">
              1. Upload Notes/PDF
            </h4>
            <p className="text-xs text-slate-400 mt-1">Extract topics, summaries & formulas</p>
          </div>

          <div
            onClick={() => setCurrentView('tutor')}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-violet-500/40 hover:bg-slate-800/70 transition-all cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-violet-500/10 text-violet-400 flex items-center justify-center group-hover:scale-110 transition-transform mb-3">
              <GraduationCap className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-violet-300">
              2. AI Exam Tutor
            </h4>
            <p className="text-xs text-slate-400 mt-1">Get 2-mark, 5-mark & 10-mark answers</p>
          </div>

          <div
            onClick={() => setCurrentView('planner')}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/40 hover:bg-slate-800/70 transition-all cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform mb-3">
              <CalendarDays className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-emerald-300">
              3. Smart Planner
            </h4>
            <p className="text-xs text-slate-400 mt-1">Personalized daily study schedules</p>
          </div>

          <div
            onClick={() => setCurrentView('quiz')}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 hover:bg-slate-800/70 transition-all cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform mb-3">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-amber-300">
              4. AI Quiz Arena
            </h4>
            <p className="text-xs text-slate-400 mt-1">Diagnose weak spots & adapt plan</p>
          </div>
        </div>
      </div>
    </div>
  );
};
