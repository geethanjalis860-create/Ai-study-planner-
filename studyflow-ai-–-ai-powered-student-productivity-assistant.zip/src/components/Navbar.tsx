import React from 'react';
import { useStudy, AppView } from '../context/StudyContext';
import {
  Sparkles,
  BookOpen,
  GraduationCap,
  CalendarDays,
  ListFilter,
  BrainCircuit,
  BarChart2,
  Flame,
  Clock,
  RotateCcw,
  Zap,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    subjects,
    stats,
    setIsRecommendationModalOpen,
    resetToDemoData,
    activeSession,
  } = useStudy();

  // Find nearest exam
  const nearestSubject = [...subjects].sort((a, b) => {
    return new Date(a.examDate).getTime() - new Date(b.examDate).getTime();
  })[0];

  let daysToNearest = 4;
  if (nearestSubject?.examDate) {
    const diff = new Date(nearestSubject.examDate).getTime() - new Date().getTime();
    daysToNearest = Math.max(1, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }

  const navItems: { id: AppView; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'materials', label: 'Study Materials', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'tutor', label: 'AI Tutor', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'planner', label: 'Study Planner', icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'priority', label: 'Task Priority', icon: <ListFilter className="w-4 h-4" /> },
    { id: 'quiz', label: 'AI Quiz Arena', icon: <BrainCircuit className="w-4 h-4" /> },
    { id: 'progress', label: 'Progress & Stats', icon: <BarChart2 className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-slate-100 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header Row */}
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentView('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-amber-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-1 ring-white/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-indigo-100 to-amber-200 bg-clip-text text-transparent">
                  StudyFlow AI
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Assistant
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Adaptive Exam Productivity Engine
              </p>
            </div>
          </div>

          {/* Center Info Pills: Nearest Exam & Streak */}
          <div className="hidden md:flex items-center gap-3">
            {nearestSubject && (
              <div
                onClick={() => setCurrentView('priority')}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/25 text-rose-300 text-xs font-semibold cursor-pointer hover:bg-rose-500/15 transition-all"
                title={`${nearestSubject.name} (${nearestSubject.code})`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span>
                  {nearestSubject.code} Exam in <strong className="text-white">{daysToNearest} Days</strong>
                </span>
              </div>
            )}

            {/* Streak */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/25 text-amber-300 text-xs font-semibold">
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-pulse" />
              <span>
                {stats.streakDays} Day Streak
              </span>
            </div>

            {/* Studied Today */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/25 text-indigo-300 text-xs font-medium">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>{Math.round(stats.totalMinutesStudied % 180)} / 180m today</span>
            </div>
          </div>

          {/* Right Action: Prominent "What Should I Do Now?" Button */}
          <div className="flex items-center gap-2 sm:gap-3">
            {activeSession && (
              <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold animate-pulse">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Session Active: {Math.floor(activeSession.elapsedSeconds / 60)}m</span>
              </div>
            )}

            {/* THE FLAGSHIP BUTTON */}
            <button
              onClick={() => setIsRecommendationModalOpen(true)}
              className="relative group overflow-hidden px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white shadow-lg shadow-indigo-600/30 transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] border border-amber-400/40 bg-gradient-to-r from-indigo-600 via-violet-600 to-amber-500 hover:from-indigo-500 hover:via-purple-500 hover:to-amber-400 cursor-pointer flex items-center gap-2"
            >
              <div className="absolute inset-0 w-1/2 h-full bg-white/20 skew-x-12 -translate-x-full group-hover:translate-x-[300%] transition-transform duration-1000 ease-in-out pointer-events-none" />
              <Zap className="w-4 h-4 text-amber-300 fill-amber-300 animate-bounce" />
              <span className="tracking-wide">What Should I Do Now?</span>
              <span className="hidden xl:inline-block px-1.5 py-0.5 rounded bg-black/30 text-[10px] text-amber-200 uppercase font-extrabold tracking-wider">
                Adaptive
              </span>
            </button>

            {/* Reset Demo Data Button */}
            <button
              onClick={resetToDemoData}
              title="Reset Demo Data"
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-2 border-t border-slate-800/80 scrollbar-none text-xs sm:text-sm font-medium">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg whitespace-nowrap transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white font-semibold shadow-md shadow-indigo-600/25 ring-1 ring-indigo-400/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.id === 'priority' && stats.weakTopicsCount > 0 && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
