import React, { useState } from 'react';
import { useStudy } from '../context/StudyContext';
import { AnswerFormat } from '../types';
import {
  GraduationCap,
  Sparkles,
  Send,
  Copy,
  Check,
  BookOpen,
  HelpCircle,
  Clock,
  Layers,
  Award,
  Zap,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'student' | 'tutor';
  text: string;
  format?: AnswerFormat;
  timestamp: number;
}

export const AITutorView: React.FC = () => {
  const { materials, subjects, selectedMaterial } = useStudy();

  const [question, setQuestion] = useState('');
  const [selectedFormat, setSelectedFormat] = useState<AnswerFormat>('5-mark');
  const [activeMaterialId, setActiveMaterialId] = useState<string>(
    selectedMaterial?.id || materials[0]?.id || ''
  );
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Pre-seed conversation with a great initial demonstration
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init-1',
      sender: 'student',
      text: 'Explain the RSA algorithm and its key generation steps.',
      format: '5-mark',
      timestamp: Date.now() - 60000,
    },
    {
      id: 'msg-init-2',
      sender: 'tutor',
      format: '5-mark',
      text: `### RSA Algorithm & Key Generation (5-Mark Exam Standard)

#### 1. Definition & Fundamental Principle
The **RSA cryptosystem** (Rivest-Shamir-Adleman) is an asymmetric public-key encryption scheme based on the mathematical intractability of **factoring large semiprime integers** into their constituent prime factors.

#### 2. Step-by-Step Key Generation Mechanism
1. **Choose Prime Numbers**: Select two large, distinct prime numbers $p$ and $q$.
2. **Compute Modulus ($n$)**: Calculate $n = p \\times q$. The bit-length of $n$ defines key security (typically 2048 or 4096 bits).
3. **Euler's Totient Function ($\\phi(n)$)**: Calculate $\\phi(n) = (p - 1)(q - 1)$.
4. **Choose Public Exponent ($e$)**: Select $e$ satisfying:
   - $1 < e < \\phi(n)$
   - $\\gcd(e, \\phi(n)) = 1$ (coprime to totient). Commonly $e = 65537$ or $e = 3$.
5. **Compute Private Exponent ($d$)**: Find modular multiplicative inverse:
   $$e \\cdot d \\equiv 1 \\pmod{\\phi(n)}$$
   (Computed efficiently using the Extended Euclidean Algorithm).
6. **Key Assignment**:
   - **Public Key**: $PU = \\{e, n\\}$ (Shared freely)
   - **Private Key**: $PR = \\{d, n\\}$ (Kept strictly secret)

#### 3. Operational Formulas
- **Encryption**: Given message $M$ ($0 \\le M < n$):
  $$C = M^e \\pmod n$$
- **Decryption**:
  $$M = C^d \\pmod n$$

#### 4. Architecture / Data Flow Representation
\`\`\`
[Plaintext M] ──> [Power e mod n (PU)] ──> [Ciphertext C]
                                                 │
[Plaintext M] <── [Power d mod n (PR)] <─────────┘
\`\`\`

#### 5. Exam Evaluator Highlight Checklist
- Always state that $p$ and $q$ must remain secret or destroyed after generating $n$ and $\\phi(n)$.
- Textbook RSA requires padding (like OAEP) to prevent chosen-ciphertext attacks.`,
      timestamp: Date.now() - 55000,
    },
  ]);

  const activeMaterial = materials.find((m) => m.id === activeMaterialId) || materials[0];

  const formatButtons: {
    format: AnswerFormat;
    label: string;
    description: string;
    icon: React.ReactNode;
    badge: string;
  }[] = [
    {
      format: 'simple',
      label: 'Simple Explanation',
      description: 'Plain English, analogies, intuitive grasp',
      icon: <Sparkles className="w-4 h-4 text-emerald-400" />,
      badge: 'Intuitive',
    },
    {
      format: '2-mark',
      label: '2-Mark Answer',
      description: 'Strict 2-4 lines, definition, formula',
      icon: <Clock className="w-4 h-4 text-amber-400" />,
      badge: 'Concise',
    },
    {
      format: '5-mark',
      label: '5-Mark Answer',
      description: 'Structured points, diagrams, mechanism',
      icon: <Layers className="w-4 h-4 text-indigo-400" />,
      badge: 'Standard',
    },
    {
      format: '10-mark',
      label: '10-Mark Answer',
      description: 'Full essay layout, math, tables, case study',
      icon: <Award className="w-4 h-4 text-rose-400" />,
      badge: 'Comprehensive',
    },
  ];

  const suggestedQuestions = activeMaterial?.suggestedQuestions?.length
    ? activeMaterial.suggestedQuestions
    : [
        'Explain how the Diffie-Hellman Key Exchange prevents eavesdropping.',
        "What are the four Coffman conditions required for an OS deadlock?",
        'Given p=3, q=11, and e=7, calculate RSA private key d.',
        'Compare symmetric encryption vs asymmetric encryption.',
      ];

  const handleAsk = async (customPrompt?: string) => {
    const textToAsk = customPrompt || question;
    if (!textToAsk.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'student',
      text: textToAsk,
      format: selectedFormat,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setQuestion('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/study/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: textToAsk,
          context: activeMaterial?.rawText || activeMaterial?.summary || '',
          answerFormat: selectedFormat,
          subject: activeMaterial?.subjectName || 'Computer Science',
        }),
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to get answer');
      }

      const tutorMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'tutor',
        text: data.answer,
        format: selectedFormat,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, tutorMsg]);
    } catch (err: any) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'tutor',
        text: `### Unable to complete request\n${err.message || 'Error communicating with AI service.'}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-indigo-400" />
            AI Exam Study Tutor
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Ask questions tailored to university exam grading criteria: Simple explanation, 2-mark, 5-mark, or 10-mark essay format.
          </p>
        </div>

        {/* Reference Material Dropdown */}
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-slate-400" />
          <select
            value={activeMaterialId}
            onChange={(e) => setActiveMaterialId(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            {materials.map((m) => (
              <option key={m.id} value={m.id}>
                Context: {m.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Format Selector Pills Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
          Select Exam Scoring Mode:
        </span>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {formatButtons.map((fb) => {
            const isSelected = selectedFormat === fb.format;
            return (
              <button
                key={fb.format}
                onClick={() => setSelectedFormat(fb.format)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-950/50 border-indigo-500 shadow-md ring-1 ring-indigo-500/40 text-white'
                    : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {fb.icon}
                    <span className="text-xs font-bold">{fb.label}</span>
                  </div>
                  <span
                    className={`text-[9px] uppercase font-extrabold px-1.5 py-0.5 rounded ${
                      isSelected ? 'bg-indigo-500/30 text-indigo-200' : 'bg-slate-700 text-slate-400'
                    }`}
                  >
                    {fb.badge}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                  {fb.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Suggested Questions Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        <span className="text-slate-400 font-bold shrink-0 flex items-center gap-1">
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          Quick Ask:
        </span>
        {suggestedQuestions.map((sq, idx) => (
          <button
            key={idx}
            onClick={() => handleAsk(sq)}
            className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-indigo-950 hover:border-indigo-500/40 border border-slate-700 text-slate-300 hover:text-indigo-200 whitespace-nowrap transition-all cursor-pointer text-xs shrink-0"
          >
            {sq}
          </button>
        ))}
      </div>

      {/* Chat History View */}
      <div className="space-y-4">
        {messages.map((msg) => {
          const isStudent = msg.sender === 'student';
          return (
            <div
              key={msg.id}
              className={`p-5 rounded-2xl border transition-all ${
                isStudent
                  ? 'bg-slate-900/90 border-slate-800 ml-auto max-w-2xl'
                  : 'bg-slate-900 border-indigo-500/30 shadow-lg'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold ${
                      isStudent
                        ? 'bg-indigo-600 text-white'
                        : 'bg-gradient-to-tr from-amber-400 to-indigo-500 text-white'
                    }`}
                  >
                    {isStudent ? 'S' : <Sparkles className="w-3.5 h-3.5" />}
                  </div>
                  <span className="text-xs font-bold text-white">
                    {isStudent ? 'You' : 'StudyFlow AI Tutor'}
                  </span>
                  {msg.format && (
                    <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-slate-800 text-indigo-300 border border-slate-700">
                      {msg.format} mode
                    </span>
                  )}
                </div>

                {!isStudent && (
                  <button
                    onClick={() => copyToClipboard(msg.text, msg.id)}
                    className="p-1 rounded text-slate-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-xs"
                    title="Copy Answer"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 text-[10px]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="text-[10px]">Copy</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Message text formatted */}
              <div className="text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2 whitespace-pre-wrap font-sans">
                {msg.text}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="p-5 rounded-2xl bg-slate-900 border border-indigo-500/30 flex items-center gap-3 text-slate-300 text-sm">
            <Sparkles className="w-5 h-5 text-amber-400 animate-spin" />
            <span>Formulating {selectedFormat} university exam answer...</span>
          </div>
        )}
      </div>

      {/* Input bar */}
      <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex items-center gap-3">
        <textarea
          rows={2}
          placeholder={`Ask any exam question (will answer in ${selectedFormat.toUpperCase()} format)...`}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleAsk();
            }
          }}
          className="flex-1 bg-transparent px-3 py-1.5 text-white text-sm focus:outline-none placeholder:text-slate-500 resize-none"
        />
        <button
          onClick={() => handleAsk()}
          disabled={isLoading || !question.trim()}
          className="px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
        >
          <span>Ask</span>
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
