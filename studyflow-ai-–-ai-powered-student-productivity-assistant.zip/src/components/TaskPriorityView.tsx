import React, { useState } from 'react';
import { useStudy } from '../context/StudyContext';
import {
  ListFilter,
  CheckCircle2,
  Circle,
  AlertTriangle,
  GraduationCap,
  BrainCircuit,
  Clock,
  Sparkles,
  ArrowUpDown,
  Filter,
} from 'lucide-react';

export const TaskPriorityView: React.FC = () => {
  const {
    topics,
    subjects,
    toggleTopicCompleted,
    calculateTopicPriority,
    setCurrentView,
  } = useStudy();

  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [filterWeakOnly, setFilterWeakOnly] = useState<boolean>(false);
  const [filterUncompletedOnly, setFilterUncompletedOnly] = useState<boolean>(true);
  const [sortBy, setSortBy] = useState<'priority' | 'difficulty' | 'mastery'>('priority');

  // Filter topics
  const filtered = topics.filter((t) => {
    if (selectedSubjectId !== 'all' && t.subjectId !== selectedSubjectId) return false;
    if (filterWeakOnly && !t.isWeakArea) return false;
    if (filterUncompletedOnly && t.completed) return false;
    return true;
  });

  // Sort
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'priority') {
      return calculateTopicPriority(b).score - calculateTopicPriority(a).score;
    }
    if (sortBy === 'difficulty') {
      return b.difficulty - a.difficulty;
    }
    return (a.mastery || 0) - (b.mastery || 0);
  });

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <ListFilter className="w-6 h-6 text-indigo-400" />
            Smart Task Prioritization Engine
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Algorithmic prioritization ranking topics by Exam Urgency (35%), Difficulty (20%), Weightage (20%), and Quiz Diagnostic Deficits (25%).
          </p>
        </div>
      </div>

      {/* Priority Formula Explainer Banner */}
      <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs text-slate-300">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <span className="font-bold text-white block">Prioritization Weighting Formula:</span>
            <span className="text-indigo-300 font-mono text-[11px]">
              Priority Score = (Days to Exam × 0.35) + (Difficulty × 0.20) + (Syllabus Importance × 0.20) + (Weak Area Deficit × 0.25)
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="px-2 py-1 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-[10px] uppercase">
            80+ Critical
          </span>
          <span className="px-2 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-[10px] uppercase">
            65-79 High
          </span>
          <span className="px-2 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700 font-bold text-[10px] uppercase">
            &lt;65 Moderate
          </span>
        </div>
      </div>

      {/* Filter and Sort Toolbar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Subject Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Subjects ({topics.length} topics)</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code}: {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Weak areas only toggle */}
          <button
            onClick={() => setFilterWeakOnly(!filterWeakOnly)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer flex items-center gap-1.5 ${
              filterWeakOnly
                ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Weak Areas Only</span>
          </button>

          {/* Hide completed toggle */}
          <button
            onClick={() => setFilterUncompletedOnly(!filterUncompletedOnly)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
              filterUncompletedOnly
                ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{filterUncompletedOnly ? 'Showing Pending' : 'Showing All (incl. Done)'}</span>
          </button>
        </div>

        {/* Sort selector */}
        <div className="flex items-center gap-2">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="priority">Sort by Highest Priority Score</option>
            <option value="difficulty">Sort by Hardest Difficulty (1-5)</option>
            <option value="mastery">Sort by Lowest Current Mastery</option>
          </select>
        </div>
      </div>

      {/* Topics Prioritized List */}
      <div className="space-y-3">
        {sorted.map((topic, index) => {
          const { score, badge, reason } = calculateTopicPriority(topic);
          return (
            <div
              key={topic.id}
              className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                topic.completed
                  ? 'bg-slate-900/50 border-slate-800/60 opacity-60'
                  : badge === 'critical'
                  ? 'bg-slate-900 border-rose-500/40 hover:border-rose-500 shadow-md shadow-rose-950/20'
                  : badge === 'high'
                  ? 'bg-slate-900 border-amber-500/40 hover:border-amber-500'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start gap-4 flex-1 min-w-0">
                {/* Ranking Index Pill */}
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-400 border border-slate-700/80 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5">
                  #{index + 1}
                </div>

                {/* Complete checkbox */}
                <button
                  onClick={() => toggleTopicCompleted(topic.id)}
                  className="mt-1 text-slate-500 hover:text-emerald-400 transition-colors cursor-pointer shrink-0"
                  title="Toggle complete"
                >
                  {topic.completed ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 fill-emerald-400/20" />
                  ) : (
                    <Circle className="w-6 h-6" />
                  )}
                </button>

                {/* Topic Metadata */}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-indigo-400">
                      {topic.subjectName}
                    </span>

                    {/* Priority Badge */}
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                        badge === 'critical'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : badge === 'high'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      Score: {score}/100 • {badge}
                    </span>

                    {/* Weak Area Indicator */}
                    {topic.isWeakArea && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-rose-950/50 text-rose-400 border border-rose-800/50 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-rose-400" />
                        Weak Diagnostic
                      </span>
                    )}

                    {/* Difficulty */}
                    <span className="text-[11px] text-slate-400 font-medium">
                      Diff: {topic.difficulty}/5
                    </span>
                  </div>

                  <h3
                    className={`text-base font-bold mt-1 ${
                      topic.completed ? 'line-through text-slate-400' : 'text-white'
                    }`}
                  >
                    {topic.title}
                  </h3>

                  <p className="text-xs text-slate-400 mt-1">{reason}</p>

                  {/* Mastery Progress Bar */}
                  <div className="mt-2.5 flex items-center gap-2 max-w-xs">
                    <span className="text-[10px] text-slate-400 font-semibold">Mastery:</span>
                    <div className="flex-1 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          topic.mastery >= 75
                            ? 'bg-emerald-400'
                            : topic.mastery >= 50
                            ? 'bg-amber-400'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${topic.mastery}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-mono font-bold text-slate-300">
                      {topic.mastery}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                <button
                  onClick={() => setCurrentView('tutor')}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Ask Tutor</span>
                </button>
                <button
                  onClick={() => setCurrentView('quiz')}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-colors cursor-pointer"
                >
                  <BrainCircuit className="w-3.5 h-3.5" />
                  <span>Test with Quiz</span>
                </button>
              </div>
            </div>
          );
        })}

        {sorted.length === 0 && (
          <div className="p-12 text-center text-slate-400 bg-slate-900 rounded-2xl border border-slate-800">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
            <h4 className="text-base font-bold text-white">All Filtered Tasks Completed!</h4>
            <p className="text-xs text-slate-400 mt-1">
              Outstanding work. Toggle filters above to see completed topics or upload more study material.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
