import React from 'react';
import { useStudy } from '../context/StudyContext';
import {
  Zap,
  X,
  Clock,
  AlertTriangle,
  Play,
  RotateCw,
  CheckCircle2,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Flame,
} from 'lucide-react';

export const WhatShouldIDoNowModal: React.FC = () => {
  const {
    isRecommendationModalOpen,
    setIsRecommendationModalOpen,
    recommendation,
    isGeneratingRecommendation,
    fetchNextActionRecommendation,
    startGuidedSession,
    setCurrentView,
  } = useStudy();

  if (!isRecommendationModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100 my-8">
        {/* Glow Header Accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-400 via-rose-500 to-indigo-600" />

        {/* Top bar */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Zap className="w-5 h-5 fill-amber-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">What Should I Do Now?</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] uppercase font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  AI Recommendation
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Calculated dynamically from your exams, recent quiz mistakes, and remaining study hours.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsRecommendationModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {recommendation ? (
            <>
              {/* Headline Banner */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/70 via-slate-900 to-violet-950/60 border border-indigo-500/30 shadow-inner">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    {recommendation.urgencyLevel} Priority Action
                  </span>
                  <div className="flex items-center gap-2 text-xs text-slate-300">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 font-semibold border border-slate-700">
                      {recommendation.subjectName}
                    </span>
                    <span className="text-amber-400 font-semibold flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Exam in {recommendation.daysLeft} days
                    </span>
                  </div>
                </div>

                <h4 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
                  {recommendation.headline}
                </h4>

                {/* AI Rationale */}
                <div className="mt-3 p-3.5 rounded-xl bg-slate-900/90 border border-slate-700/60 text-xs sm:text-sm text-slate-300 leading-relaxed">
                  <span className="font-bold text-amber-300 flex items-center gap-1.5 mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    Why this right now?
                  </span>
                  {recommendation.reason}
                </div>
              </div>

              {/* 3-Step Guided Action Plan */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    Recommended {recommendation.totalMinutes}-Minute Action Sprint
                  </h5>
                  <span className="text-xs text-slate-400 font-medium">
                    Total: {recommendation.totalMinutes} minutes
                  </span>
                </div>

                <div className="space-y-3">
                  {recommendation.steps.map((step, idx) => (
                    <div
                      key={idx}
                      className="group p-4 rounded-xl bg-slate-800/60 hover:bg-slate-800/90 border border-slate-700/50 hover:border-indigo-500/40 transition-all flex items-start gap-3.5"
                    >
                      <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        {step.stepNumber}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h6 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                            {step.title}
                          </h6>
                          <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-900 text-amber-300 border border-slate-700 shrink-0">
                            {step.minutes} min
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1 leading-normal">
                          {step.instruction}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Motivational Tip */}
              {recommendation.motivationalTip && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center gap-3 text-xs text-amber-200">
                  <Flame className="w-5 h-5 text-amber-400 shrink-0" />
                  <p className="italic">{recommendation.motivationalTip}</p>
                </div>
              )}
            </>
          ) : (
            <div className="p-8 text-center text-slate-400">
              <Sparkles className="w-8 h-8 text-indigo-400 mx-auto mb-2 animate-spin" />
              <p>Analyzing student state and generating your next priority action...</p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-slate-800 bg-slate-950/70 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => fetchNextActionRecommendation()}
            disabled={isGeneratingRecommendation}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-700 hover:border-slate-600 bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isGeneratingRecommendation ? 'animate-spin' : ''}`} />
            <span>{isGeneratingRecommendation ? 'Recalculating...' : 'Refresh AI Analysis'}</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                setIsRecommendationModalOpen(false);
                setCurrentView('tutor');
              }}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-indigo-500/30 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <GraduationCap className="w-4 h-4" />
              <span>Ask AI Tutor</span>
            </button>

            <button
              onClick={() => startGuidedSession()}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:from-amber-400 hover:via-rose-400 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Start Guided Session ({recommendation?.totalMinutes || 30}m)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
