import React from 'react';
import { useStudy } from '../context/StudyContext';
import {
  BarChart2,
  TrendingUp,
  Flame,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Award,
  Sparkles,
  BookOpen,
  Calendar,
  GraduationCap,
  BrainCircuit,
  ArrowRight,
} from 'lucide-react';

export const ProgressView: React.FC = () => {
  const {
    stats,
    subjects,
    topics,
    quizHistory,
    studyLogs,
    setCurrentView,
  } = useStudy();

  const weakTopics = topics.filter((t) => t.isWeakArea);
  const completedTopics = topics.filter((t) => t.completed);

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <BarChart2 className="w-6 h-6 text-indigo-400" />
            Student Progress & Exam Readiness Analytics
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Real-time tracking of topic mastery, diagnostic scores, weak subject areas, and study streak consistency.
          </p>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Exam Readiness
            </span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.overallReadinessPercentage}%
            </span>
            <span className="text-xs text-emerald-400 font-semibold">Mastery Index</span>
          </div>
          <div className="mt-3 w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-emerald-400"
              style={{ width: `${stats.overallReadinessPercentage}%` }}
            />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Active Streak
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Flame className="w-4 h-4 fill-amber-400" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.streakDays}
            </span>
            <span className="text-xs text-amber-400 font-semibold">Consecutive Days 🔥</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Daily study habit streak</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Topics Completed
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.completedTopicsCount} / {stats.totalTopicsCount}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {stats.totalTopicsCount - stats.completedTopicsCount} remaining before exams
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Average Quiz Score
            </span>
            <div className="p-2 rounded-xl bg-violet-500/10 text-violet-400">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">
              {stats.averageQuizScore}%
            </span>
            <span className="text-xs text-slate-400 font-medium">({stats.quizzesTakenCount} tests)</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Evaluated across all subjects</p>
        </div>
      </div>

      {/* Subject-by-Subject Breakdown */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          Subject Preparedness Breakdown
        </h3>

        <div className="space-y-4">
          {subjects.map((subj) => {
            const subjTopics = topics.filter((t) => t.subjectId === subj.id);
            const subjCompleted = subjTopics.filter((t) => t.completed).length;
            const percent = subjTopics.length > 0 ? Math.round((subjCompleted / subjTopics.length) * 100) : 0;
            const diffMs = new Date(subj.examDate).getTime() - new Date().getTime();
            const daysLeft = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));

            return (
              <div
                key={subj.id}
                className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2.5"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold text-white">
                      {subj.code}: {subj.name}
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      Exam: {subj.examDate} ({daysLeft} days remaining)
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-indigo-400">{percent}%</span>
                    <span className="text-[10px] text-slate-400 block">
                      {subjCompleted} of {subjTopics.length} topics mastered
                    </span>
                  </div>
                </div>

                <div className="w-full h-2 rounded-full bg-slate-700 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-indigo-500 transition-all duration-500"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Weak Areas Hub */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-400" />
            Diagnosed Weak Topics Needing Remediation ({weakTopics.length})
          </h3>
          <span className="text-xs text-rose-400 font-semibold">Priority focus areas</span>
        </div>

        {weakTopics.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {weakTopics.map((topic) => (
              <div
                key={topic.id}
                className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/30 flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-indigo-400">
                      {topic.subjectName}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-rose-500/20 text-rose-300 border border-rose-500/40">
                      Mastery: {topic.mastery}%
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white mt-1.5">{topic.title}</h4>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{topic.summary}</p>
                </div>

                <div className="flex items-center gap-2 pt-1 border-t border-rose-500/20">
                  <button
                    onClick={() => setCurrentView('tutor')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Ask Tutor</span>
                  </button>
                  <button
                    onClick={() => setCurrentView('quiz')}
                    className="px-3 py-1.5 rounded-lg bg-rose-600/30 hover:bg-rose-600/40 text-rose-200 border border-rose-500/40 text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <BrainCircuit className="w-3.5 h-3.5" />
                    <span>Retake Quiz</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-center text-xs text-emerald-300">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto mb-1.5" />
            <span>No critical weak topics flagged! Your diagnostic retention is above 60%.</span>
          </div>
        )}
      </div>

      {/* Study Session Log History */}
      {studyLogs.length > 0 && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-400" />
            Completed Guided Study Sprints Log
          </h3>

          <div className="space-y-2.5">
            {studyLogs.map((log) => (
              <div
                key={log.id}
                className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-white">{log.topicTitle}</span>
                  <span className="text-slate-400 block text-[11px] mt-0.5">
                    {log.subjectName} • {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex items-center gap-2 font-mono text-emerald-400 font-bold">
                  <span>+{log.durationMinutes} mins</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
