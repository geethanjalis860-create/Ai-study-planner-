import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Subject,
  Topic,
  StudyMaterial,
  QuizResult,
  StudentStats,
  NextActionRecommendation,
  StudyPlanDay,
  StudySessionLog,
  PriorityLevel,
} from '../types';
import {
  INITIAL_SUBJECTS,
  INITIAL_TOPICS,
  INITIAL_MATERIALS,
  INITIAL_QUIZ_RESULTS,
  INITIAL_RECOMMENDATION,
  INITIAL_STATS,
} from '../data/seedData';

export type AppView = 'dashboard' | 'materials' | 'tutor' | 'planner' | 'priority' | 'quiz' | 'progress';

interface ActiveStudySession {
  isRunning: boolean;
  currentStepIndex: number;
  elapsedSeconds: number;
  totalTargetSeconds: number;
  recommendation: NextActionRecommendation;
  completedStepIndices: number[];
}

interface StudyContextType {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  subjects: Subject[];
  topics: Topic[];
  materials: StudyMaterial[];
  selectedMaterial: StudyMaterial | null;
  setSelectedMaterial: (mat: StudyMaterial | null) => void;
  quizHistory: QuizResult[];
  recommendation: NextActionRecommendation | null;
  stats: StudentStats;
  studyPlan: StudyPlanDay[];
  setStudyPlan: (plan: StudyPlanDay[]) => void;
  studyLogs: StudySessionLog[];
  isGeneratingRecommendation: boolean;
  isRecommendationModalOpen: boolean;
  setIsRecommendationModalOpen: (open: boolean) => void;
  activeSession: ActiveStudySession | null;

  // Actions
  addSubject: (subj: Omit<Subject, 'id' | 'totalTopics' | 'completedTopics' | 'confidenceLevel'>) => void;
  toggleTopicCompleted: (topicId: string) => void;
  updateTopicMastery: (topicId: string, mastery: number) => void;
  addMaterial: (mat: StudyMaterial) => void;
  recordQuizResult: (result: QuizResult) => void;
  fetchNextActionRecommendation: (overrideTopics?: Topic[]) => Promise<void>;
  startGuidedSession: (rec?: NextActionRecommendation) => void;
  toggleSessionTimer: () => void;
  markSessionStepDone: (stepIndex: number) => void;
  finishStudySession: () => void;
  cancelStudySession: () => void;
  resetToDemoData: () => void;
  calculateTopicPriority: (topic: Topic) => { score: number; badge: PriorityLevel; reason: string };
}

const StudyContext = createContext<StudyContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SUBJECTS: 'studyflow_subjects_v1',
  TOPICS: 'studyflow_topics_v1',
  MATERIALS: 'studyflow_materials_v1',
  QUIZZES: 'studyflow_quizzes_v1',
  REC: 'studyflow_rec_v1',
  STATS: 'studyflow_stats_v1',
  PLAN: 'studyflow_plan_v1',
  LOGS: 'studyflow_logs_v1',
};

export const StudyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>('dashboard');

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SUBJECTS);
    return saved ? JSON.parse(saved) : INITIAL_SUBJECTS;
  });

  const [topics, setTopics] = useState<Topic[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TOPICS);
    return saved ? JSON.parse(saved) : INITIAL_TOPICS;
  });

  const [materials, setMaterials] = useState<StudyMaterial[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MATERIALS);
    return saved ? JSON.parse(saved) : INITIAL_MATERIALS;
  });

  const [selectedMaterial, setSelectedMaterial] = useState<StudyMaterial | null>(null);

  const [quizHistory, setQuizHistory] = useState<QuizResult[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.QUIZZES);
    return saved ? JSON.parse(saved) : INITIAL_QUIZ_RESULTS;
  });

  const [recommendation, setRecommendation] = useState<NextActionRecommendation | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REC);
    return saved ? JSON.parse(saved) : INITIAL_RECOMMENDATION;
  });

  const [stats, setStats] = useState<StudentStats>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STATS);
    return saved ? JSON.parse(saved) : INITIAL_STATS;
  });

  const [studyPlan, setStudyPlan] = useState<StudyPlanDay[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PLAN);
    return saved ? JSON.parse(saved) : [];
  });

  const [studyLogs, setStudyLogs] = useState<StudySessionLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    return saved ? JSON.parse(saved) : [];
  });

  const [isGeneratingRecommendation, setIsGeneratingRecommendation] = useState(false);
  const [isRecommendationModalOpen, setIsRecommendationModalOpen] = useState(false);
  const [activeSession, setActiveSession] = useState<ActiveStudySession | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TOPICS, JSON.stringify(topics));
  }, [topics]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MATERIALS, JSON.stringify(materials));
  }, [materials]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(quizHistory));
  }, [quizHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REC, JSON.stringify(recommendation));
  }, [recommendation]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PLAN, JSON.stringify(studyPlan));
  }, [studyPlan]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(studyLogs));
  }, [studyLogs]);

  // Session timer ticker
  useEffect(() => {
    let timer: any = null;
    if (activeSession && activeSession.isRunning) {
      timer = setInterval(() => {
        setActiveSession((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            elapsedSeconds: prev.elapsedSeconds + 1,
          };
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [activeSession?.isRunning]);

  // Priority formula calculation
  const calculateTopicPriority = (topic: Topic): { score: number; badge: PriorityLevel; reason: string } => {
    const subj = subjects.find((s) => s.id === topic.subjectId);
    let daysUntilExam = 14;
    if (subj?.examDate) {
      const diffMs = new Date(subj.examDate).getTime() - new Date().getTime();
      daysUntilExam = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    }

    // Urgency factor: 0-100 (1 day away = 100, 14 days away = 20)
    const urgencyScore = Math.min(100, Math.max(10, Math.round(100 - daysUntilExam * 6)));

    // Difficulty score: 1 to 5 mapped to 20-100
    const diffScore = topic.difficulty * 20;

    // Importance: high=100, medium=60, low=30
    const impScore = topic.importance === 'high' ? 100 : topic.importance === 'medium' ? 60 : 30;

    // Mastery deficit: (100 - mastery)
    const masteryDeficit = 100 - (topic.mastery || 0);

    // Weak area bonus
    const weakAreaBonus = topic.isWeakArea ? 30 : 0;

    // Completion penalty
    const completionFactor = topic.completed ? 0.2 : 1.0;

    const rawScore = (urgencyScore * 0.35 + diffScore * 0.2 + impScore * 0.2 + (masteryDeficit + weakAreaBonus) * 0.25) * completionFactor;
    const finalScore = Math.min(99, Math.max(15, Math.round(rawScore)));

    let badge: PriorityLevel = 'low';
    if (finalScore >= 80) badge = 'critical';
    else if (finalScore >= 65) badge = 'high';
    else if (finalScore >= 45) badge = 'medium';

    let reason = '';
    if (topic.isWeakArea) {
      reason = `Flagged as weak area (${topic.mastery}% mastery) with exam in ${daysUntilExam} days.`;
    } else if (daysUntilExam <= 5) {
      reason = `Exam approaching rapidly in ${daysUntilExam} days! High weightage module.`;
    } else if (topic.importance === 'high') {
      reason = `High syllabus importance with ${diffScore / 20}/5 difficulty rating.`;
    } else {
      reason = `Scheduled revision for comprehensive retention.`;
    }

    return { score: finalScore, badge, reason };
  };

  // Re-calculate stats on topics or quizzes change
  const refreshStats = (currentTopics: Topic[], currentQuizzes: QuizResult[]) => {
    const totalCount = currentTopics.length;
    const completedCount = currentTopics.filter((t) => t.completed).length;
    const weakCount = currentTopics.filter((t) => t.isWeakArea).length;

    let avgQuiz = 70;
    if (currentQuizzes.length > 0) {
      const sum = currentQuizzes.reduce((acc, q) => acc + q.percentage, 0);
      avgQuiz = Math.round(sum / currentQuizzes.length);
    }

    const readiness = totalCount > 0
      ? Math.round((completedCount / totalCount) * 60 + (avgQuiz * 0.4))
      : 50;

    setStats((prev) => ({
      ...prev,
      completedTopicsCount: completedCount,
      totalTopicsCount: totalCount,
      weakTopicsCount: weakCount,
      quizzesTakenCount: currentQuizzes.length,
      averageQuizScore: avgQuiz,
      overallReadinessPercentage: Math.min(100, Math.max(10, readiness)),
    }));
  };

  const addSubject = (subj: Omit<Subject, 'id' | 'totalTopics' | 'completedTopics' | 'confidenceLevel'>) => {
    const newSubject: Subject = {
      ...subj,
      id: `subj-${Date.now()}`,
      totalTopics: 0,
      completedTopics: 0,
      confidenceLevel: 50,
    };
    setSubjects((prev) => [...prev, newSubject]);
  };

  const toggleTopicCompleted = (topicId: string) => {
    const updated = topics.map((t) => {
      if (t.id === topicId) {
        const nextCompleted = !t.completed;
        return {
          ...t,
          completed: nextCompleted,
          mastery: nextCompleted ? Math.max(t.mastery, 85) : Math.min(t.mastery, 45),
          isWeakArea: nextCompleted ? false : t.isWeakArea,
        };
      }
      return t;
    });
    setTopics(updated);
    refreshStats(updated, quizHistory);

    // If completed, trigger subtle celebratory confetti
    const toggled = updated.find((t) => t.id === topicId);
    if (toggled?.completed) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
      });
    }
  };

  const updateTopicMastery = (topicId: string, mastery: number) => {
    const updated = topics.map((t) => {
      if (t.id === topicId) {
        return {
          ...t,
          mastery,
          isWeakArea: mastery < 60,
          completed: mastery >= 85,
        };
      }
      return t;
    });
    setTopics(updated);
    refreshStats(updated, quizHistory);
  };

  const addMaterial = (mat: StudyMaterial) => {
    setMaterials((prev) => [mat, ...prev]);
    setSelectedMaterial(mat);

    // Auto-create topics from extracted material if available
    if (mat.keyConcepts && mat.keyConcepts.length > 0) {
      const newTopics: Topic[] = mat.keyConcepts.map((kc, idx) => ({
        id: `topic-extracted-${Date.now()}-${idx}`,
        subjectId: mat.subjectId,
        subjectName: mat.subjectName,
        title: kc.title,
        summary: kc.explanation,
        difficulty: 3,
        importance: 'high',
        completed: false,
        mastery: 35,
        isWeakArea: false,
        estimatedMinutes: 25,
        keyPoints: [kc.explanation],
      }));
      setTopics((prev) => [...prev, ...newTopics]);
    }
  };

  // Record quiz result -> automatically updates topic mastery & triggers adaptive recommendation
  const recordQuizResult = (result: QuizResult) => {
    const updatedQuizzes = [result, ...quizHistory];
    setQuizHistory(updatedQuizzes);

    // Adapt topics based on weak and mastered areas
    const updatedTopics = topics.map((topic) => {
      // Check if topic matches any weak topic from the quiz
      const isNowWeak = result.weakTopics.some(
        (wt) => topic.title.toLowerCase().includes(wt.toLowerCase()) || wt.toLowerCase().includes(topic.title.toLowerCase())
      );
      const isNowMastered = result.masteredTopics.some(
        (mt) => topic.title.toLowerCase().includes(mt.toLowerCase()) || mt.toLowerCase().includes(topic.title.toLowerCase())
      );

      if (isNowWeak) {
        return {
          ...topic,
          isWeakArea: true,
          mastery: Math.max(20, Math.min(50, topic.mastery - 15)),
          lastQuizScore: result.percentage,
        };
      } else if (isNowMastered) {
        return {
          ...topic,
          isWeakArea: false,
          mastery: Math.min(95, Math.max(75, topic.mastery + 20)),
          lastQuizScore: result.percentage,
        };
      }
      return topic;
    });

    setTopics(updatedTopics);
    refreshStats(updatedTopics, updatedQuizzes);

    // Automatically refresh "What Should I Do Now?" to reflect the new test diagnosis!
    fetchNextActionRecommendation(updatedTopics);

    if (result.percentage >= 80) {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  };

  // Fetch the adaptive recommendation from the server AI
  const fetchNextActionRecommendation = async (overrideTopics?: Topic[]) => {
    setIsGeneratingRecommendation(true);
    try {
      const activeTopics = overrideTopics || topics;
      const res = await fetch('/api/study/recommend-next-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subjects,
          topics: activeTopics,
          recentQuizzes: quizHistory.slice(0, 5),
          targetHours: 3,
          studiedMinutesToday: 45,
        }),
      });

      const data = await res.json();
      if (data.success && data.recommendation) {
        setRecommendation(data.recommendation);
      }
    } catch (err) {
      console.error('Error fetching recommendation:', err);
    } finally {
      setIsGeneratingRecommendation(false);
    }
  };

  // Guided Study Session (The interactive action for "What Should I Do Now?")
  const startGuidedSession = (rec?: NextActionRecommendation) => {
    const targetRec = rec || recommendation;
    if (!targetRec) return;

    setActiveSession({
      isRunning: true,
      currentStepIndex: 0,
      elapsedSeconds: 0,
      totalTargetSeconds: targetRec.totalMinutes * 60,
      recommendation: targetRec,
      completedStepIndices: [],
    });
    setIsRecommendationModalOpen(false);
  };

  const toggleSessionTimer = () => {
    if (!activeSession) return;
    setActiveSession((prev) => (prev ? { ...prev, isRunning: !prev.isRunning } : null));
  };

  const markSessionStepDone = (stepIndex: number) => {
    if (!activeSession) return;
    const exists = activeSession.completedStepIndices.includes(stepIndex);
    const updated = exists
      ? activeSession.completedStepIndices.filter((i) => i !== stepIndex)
      : [...activeSession.completedStepIndices, stepIndex];

    setActiveSession({
      ...activeSession,
      completedStepIndices: updated,
      currentStepIndex: Math.min(stepIndex + 1, activeSession.recommendation.steps.length - 1),
    });

    confetti({
      particleCount: 30,
      spread: 50,
      origin: { y: 0.8 },
    });
  };

  const finishStudySession = () => {
    if (!activeSession) return;

    const durationMin = Math.max(1, Math.round(activeSession.elapsedSeconds / 60));

    // Create session log
    const newLog: StudySessionLog = {
      id: `log-${Date.now()}`,
      topicTitle: activeSession.recommendation.topicTitle,
      subjectName: activeSession.recommendation.subjectName,
      durationMinutes: durationMin,
      timestamp: Date.now(),
      completedStepsCount: activeSession.completedStepIndices.length,
    };
    setStudyLogs((prev) => [newLog, ...prev]);

    // Update stats: add minutes, increment streak if first today
    setStats((prev) => ({
      ...prev,
      totalMinutesStudied: prev.totalMinutesStudied + durationMin,
      streakDays: prev.streakDays + 1,
    }));

    // Update target topic mastery: reward student
    const targetTopicId = activeSession.recommendation.topicId;
    if (targetTopicId) {
      const updatedTopics = topics.map((t) => {
        if (t.id === targetTopicId) {
          return {
            ...t,
            mastery: Math.min(90, t.mastery + 25),
            isWeakArea: false,
          };
        }
        return t;
      });
      setTopics(updatedTopics);
      refreshStats(updatedTopics, quizHistory);
    }

    setActiveSession(null);

    // Grand celebration confetti
    confetti({
      particleCount: 120,
      spread: 100,
      origin: { y: 0.5 },
    });
  };

  const cancelStudySession = () => {
    setActiveSession(null);
  };

  const resetToDemoData = () => {
    localStorage.clear();
    setSubjects(INITIAL_SUBJECTS);
    setTopics(INITIAL_TOPICS);
    setMaterials(INITIAL_MATERIALS);
    setSelectedMaterial(INITIAL_MATERIALS[0]);
    setQuizHistory(INITIAL_QUIZ_RESULTS);
    setRecommendation(INITIAL_RECOMMENDATION);
    setStats(INITIAL_STATS);
    setStudyPlan([]);
    setStudyLogs([]);
    setActiveSession(null);
  };

  return (
    <StudyContext.Provider
      value={{
        currentView,
        setCurrentView,
        subjects,
        topics,
        materials,
        selectedMaterial,
        setSelectedMaterial,
        quizHistory,
        recommendation,
        stats,
        studyPlan,
        setStudyPlan,
        studyLogs,
        isGeneratingRecommendation,
        isRecommendationModalOpen,
        setIsRecommendationModalOpen,
        activeSession,
        addSubject,
        toggleTopicCompleted,
        updateTopicMastery,
        addMaterial,
        recordQuizResult,
        fetchNextActionRecommendation,
        startGuidedSession,
        toggleSessionTimer,
        markSessionStepDone,
        finishStudySession,
        cancelStudySession,
        resetToDemoData,
        calculateTopicPriority,
      }}
    >
      {children}
    </StudyContext.Provider>
  );
};

export const useStudy = () => {
  const context = useContext(StudyContext);
  if (!context) {
    throw new Error('useStudy must be used within a StudyProvider');
  }
  return context;
};
