import { Subject, Topic, StudyMaterial, QuizResult, StudentStats, NextActionRecommendation } from '../types';

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 'subj-cs401',
    name: 'Cryptography & Network Security',
    code: 'CS401',
    examDate: '2026-10-12', // 4 days away
    color: 'indigo',
    icon: 'Shield',
    totalTopics: 5,
    completedTopics: 2,
    confidenceLevel: 58,
  },
  {
    id: 'subj-cs302',
    name: 'Operating Systems & Concurrency',
    code: 'CS302',
    examDate: '2026-10-18', // 10 days away
    color: 'emerald',
    icon: 'Cpu',
    totalTopics: 6,
    completedTopics: 4,
    confidenceLevel: 75,
  },
  {
    id: 'subj-math205',
    name: 'Probability & Applied Statistics',
    code: 'MATH205',
    examDate: '2026-10-25', // 17 days away
    color: 'amber',
    icon: 'BarChart3',
    totalTopics: 4,
    completedTopics: 2,
    confidenceLevel: 65,
  },
];

export const INITIAL_TOPICS: Topic[] = [
  {
    id: 'topic-rsa',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    title: 'RSA Algorithm & Modular Math',
    summary: 'Public key asymmetric encryption based on the hardness of integer factorization.',
    difficulty: 4,
    importance: 'high',
    completed: false,
    mastery: 42,
    isWeakArea: true,
    lastQuizScore: 40,
    estimatedMinutes: 30,
    keyPoints: [
      'Key generation: n = p*q, phi(n) = (p-1)*(q-1)',
      'Condition for e: 1 < e < phi(n) and gcd(e, phi(n)) = 1',
      'Private key d: e*d ≡ 1 (mod phi(n))',
      'Encryption: C = M^e mod n, Decryption: M = C^d mod n',
    ],
  },
  {
    id: 'topic-diffie',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    title: 'Diffie-Hellman Key Exchange',
    summary: 'Method of securely exchanging cryptographic keys over a public channel using discrete logarithms.',
    difficulty: 3,
    importance: 'high',
    completed: false,
    mastery: 55,
    isWeakArea: false,
    lastQuizScore: 60,
    estimatedMinutes: 25,
    keyPoints: [
      'Relies on discrete logarithm problem in prime fields',
      'Vulnerable to Man-in-the-Middle (MitM) without digital signatures',
      'Shared secret K = (g^a)^b mod p = (g^b)^a mod p',
    ],
  },
  {
    id: 'topic-aes',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    title: 'AES Symmetric Block Cipher',
    summary: 'Rijndael block cipher using 128-bit blocks and 10/12/14 transformation rounds.',
    difficulty: 4,
    importance: 'medium',
    completed: true,
    mastery: 88,
    isWeakArea: false,
    lastQuizScore: 90,
    estimatedMinutes: 35,
    keyPoints: [
      'SubBytes (non-linear S-box substitution)',
      'ShiftRows (transposition)',
      'MixColumns (matrix multiplication in GF(2^8))',
      'AddRoundKey (XOR with round subkeys)',
    ],
  },
  {
    id: 'topic-sha256',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    title: 'SHA-256 & Digital Signatures',
    summary: 'Cryptographic hash functions and asymmetric non-repudiation verification.',
    difficulty: 3,
    importance: 'medium',
    completed: true,
    mastery: 85,
    isWeakArea: false,
    lastQuizScore: 85,
    estimatedMinutes: 20,
    keyPoints: [
      'Pre-image resistance, second pre-image resistance, collision resistance',
      'Merkle-Damgard construction',
      'Digital signature = encrypt hash with private key',
    ],
  },
  {
    id: 'topic-firewall',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    title: 'Firewalls & Intrusion Detection (IDS)',
    summary: 'Packet filtering, stateful inspection, and anomaly-based intrusion detection.',
    difficulty: 2,
    importance: 'low',
    completed: false,
    mastery: 50,
    isWeakArea: false,
    estimatedMinutes: 20,
    keyPoints: [
      'Packet filter operates at network layer (OSI layer 3/4)',
      'Stateful firewall tracks TCP handshakes',
      'Signature-based vs anomaly-based detection',
    ],
  },
  {
    id: 'topic-deadlocks',
    subjectId: 'subj-cs302',
    subjectName: 'Operating Systems & Concurrency',
    title: "Deadlocks & Banker's Algorithm",
    summary: 'Coffman four deadlock conditions and resource allocation avoidance algorithms.',
    difficulty: 4,
    importance: 'high',
    completed: false,
    mastery: 48,
    isWeakArea: true,
    lastQuizScore: 50,
    estimatedMinutes: 35,
    keyPoints: [
      '4 Conditions: Mutual exclusion, Hold & wait, No preemption, Circular wait',
      "Banker's Algorithm: Need matrix = Max - Allocation",
      'Safe state guarantees sequence of execution without deadlocks',
    ],
  },
  {
    id: 'topic-scheduling',
    subjectId: 'subj-cs302',
    subjectName: 'Operating Systems & Concurrency',
    title: 'CPU Scheduling Algorithms',
    summary: 'FCFS, SJF, Round Robin, and Multi-Level Feedback Queue performance analysis.',
    difficulty: 3,
    importance: 'high',
    completed: true,
    mastery: 92,
    isWeakArea: false,
    lastQuizScore: 95,
    estimatedMinutes: 25,
    keyPoints: [
      'Turnaround Time = Completion Time - Arrival Time',
      'Waiting Time = Turnaround Time - Burst Time',
      'Convoy effect in FCFS; starvation in Priority/SJF',
    ],
  },
  {
    id: 'topic-virtualmem',
    subjectId: 'subj-cs302',
    subjectName: 'Operating Systems & Concurrency',
    title: 'Virtual Memory & Page Replacement',
    summary: 'Demand paging, TLB translation, FIFO, LRU, and Optimal page replacement.',
    difficulty: 4,
    importance: 'high',
    completed: false,
    mastery: 60,
    isWeakArea: false,
    estimatedMinutes: 30,
    keyPoints: [
      "Bélády's anomaly occurs in FIFO replacement",
      'LRU uses stack or counters to track least recently used pages',
      'Thrashing occurs when working set exceeds physical frames',
    ],
  },
  {
    id: 'topic-bayes',
    subjectId: 'subj-math205',
    subjectName: 'Probability & Applied Statistics',
    title: "Bayes' Theorem & Conditional Probability",
    summary: 'Posterior probability calculation given prior probabilities and likelihood.',
    difficulty: 3,
    importance: 'high',
    completed: true,
    mastery: 80,
    isWeakArea: false,
    lastQuizScore: 80,
    estimatedMinutes: 25,
    keyPoints: [
      'P(A|B) = [P(B|A) * P(A)] / P(B)',
      'Law of Total Probability expands denominator',
      'Prior, Likelihood, Posterior, and Evidence terms',
    ],
  },
  {
    id: 'topic-distributions',
    subjectId: 'subj-math205',
    subjectName: 'Probability & Applied Statistics',
    title: 'Continuous Distributions (Normal & Exponential)',
    summary: 'Probability density functions, Z-scores, standard normal tables, and memoryless property.',
    difficulty: 4,
    importance: 'medium',
    completed: false,
    mastery: 50,
    isWeakArea: false,
    estimatedMinutes: 30,
    keyPoints: [
      'Standard Normal Z = (X - μ) / σ',
      'Empirical Rule: 68% - 95% - 99.7%',
      'Exponential distribution is memoryless: P(X > s+t | X > s) = P(X > t)',
    ],
  },
];

export const INITIAL_MATERIALS: StudyMaterial[] = [
  {
    id: 'mat-rsa-notes',
    title: 'Unit 3: Public Key Cryptography & RSA Deep-Dive',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    fileName: 'CS401_Unit3_RSA_Lecture_Notes.pdf',
    fileType: 'pdf',
    uploadDate: '2026-10-06',
    rawText: `Unit 3: Public Key Cryptography and the RSA Algorithm.
Introduction to Asymmetric Cryptosystems:
Unlike symmetric encryption where a single secret key is shared between communicating parties, asymmetric cryptography uses key pairs. Each entity possesses a public key (distributed freely) and a private key (guarded secretly).

RSA Algorithm (Rivest, Shamir, Adleman - 1977):
The RSA algorithm is based on the mathematical difficulty of factoring the product of two large prime numbers.
Key Generation Steps:
1. Select two distinct large prime numbers p and q.
2. Compute modulus n = p * q.
3. Compute Euler's Totient function: phi(n) = (p - 1) * (q - 1).
4. Select public exponent e such that: 1 < e < phi(n) and gcd(e, phi(n)) = 1 (coprime to phi(n)). Common values include 3, 17, or 65537.
5. Compute private key exponent d such that: e * d ≡ 1 (mod phi(n)), meaning d is the modular multiplicative inverse of e mod phi(n).
6. Public Key: PU = {e, n}.
7. Private Key: PR = {d, n}.

Encryption & Decryption:
Given plaintext message M such that 0 <= M < n:
Ciphertext C = M^e mod n.
Decryption:
Plaintext M = C^d mod n.

Proof of correctness relies on Euler's theorem: if gcd(M, n) = 1, then M^(phi(n)) ≡ 1 (mod n).
Since e * d = k * phi(n) + 1, M^(e*d) = M^(k*phi(n) + 1) = (M^(phi(n)))^k * M ≡ 1^k * M ≡ M (mod n).

Security Considerations & Exam Questions:
- Factorization Hardness: Factoring n into p and q breaks RSA because phi(n) can then be easily calculated, allowing d to be derived from e.
- Chosen Ciphertext Attacks: Textbook RSA is malleable. Optimal Asymmetric Encryption Padding (OAEP) must be applied in production.
- Computational Complexity: Modular exponentiation using the Square-and-Multiply algorithm runs in O(log e) multiplications.`,
    summary: 'Comprehensive notes covering RSA key pair derivation, Euler totient theorem proofs, modular arithmetic, square-and-multiply computational efficiency, and practical padding safeguards against chosen ciphertext attacks.',
    keyConcepts: [
      {
        title: 'Asymmetric Key Principle',
        explanation: 'Encryption uses public key (e, n); decryption requires matching mathematical private key (d, n) known only to receiver.',
      },
      {
        title: "Euler's Totient Function phi(n)",
        explanation: 'Calculates the number of positive integers less than n that are coprime to n. For primes p, q: phi(n) = (p - 1)(q - 1).',
      },
      {
        title: 'Modular Inverse',
        explanation: 'd is the unique inverse of e modulo phi(n), derived using the Extended Euclidean Algorithm.',
      },
    ],
    formulas: [
      'Modulus: n = p * q',
      'Totient: phi(n) = (p - 1) * (q - 1)',
      'Coprime condition: gcd(e, phi(n)) = 1',
      'Inverse: e * d ≡ 1 mod phi(n)',
      'Ciphertext: C = M^e mod n',
      'Plaintext: M = C^d mod n',
    ],
    examHotspots: [
      'Step-by-step numerical calculation with small primes p=3, q=11, e=7 (frequent 5-mark question).',
      'Why is gcd(e, phi(n)) = 1 mandatory? (2-mark answer: ensures existence of multiplicative inverse d).',
      'Differences between textbook RSA and OAEP padded RSA.',
    ],
    suggestedQuestions: [
      'Explain the RSA algorithm with a neat block diagram and mathematical derivation.',
      'Given p=5, q=11, and e=3, encrypt message M=9 and verify decryption.',
      'What is Euler’s Totient Theorem and how does it guarantee RSA decryption correctness?',
    ],
  },
  {
    id: 'mat-deadlock-notes',
    title: 'Unit 4: Deadlocks, Prevention, and Banker’s Algorithm',
    subjectId: 'subj-cs302',
    subjectName: 'Operating Systems & Concurrency',
    fileName: 'OS_Deadlocks_Reference.pdf',
    fileType: 'notes',
    uploadDate: '2026-10-05',
    rawText: `Operating Systems: Deadlock Management and Resource Allocation.
A deadlock occurs when a set of concurrent processes are permanently blocked because each process holds a resource and waits for another resource held by another process in the same set.

The 4 Coffman Conditions (Must simultaneously hold for a deadlock):
1. Mutual Exclusion: At least one resource must be held in non-shareable mode.
2. Hold and Wait: A process must hold at least one resource and wait to acquire additional resources currently held by others.
3. No Preemption: Resources cannot be forcibly taken away; they are released only voluntarily.
4. Circular Wait: A closed chain of processes exists such that each process holds at least one resource needed by the next process in the chain.

Deadlock Handling Strategies:
1. Deadlock Prevention: Eliminate at least one of the 4 Coffman conditions.
2. Deadlock Avoidance: System dynamically assesses resource allocation state to ensure safe states (e.g. Banker's Algorithm).
3. Deadlock Detection & Recovery: Allow deadlocks to occur, run detection algorithms (resource allocation graph cycle check), and recover via process termination or preemption.
4. Ostrich Algorithm: Ignore the problem (used in general purpose OS like Linux and Windows due to rare occurrences).

Banker's Algorithm Data Structures:
- Available[m]: Available instances of resource type j.
- Max[n][m]: Maximum demand of process i for resource j.
- Allocation[n][m]: Currently allocated instances to process i.
- Need[n][m] = Max[i][j] - Allocation[i][j].`,
    summary: "Detailed overview of operating system deadlocks, four necessary Coffman conditions, avoidance through Dijkstra's Banker's algorithm safe sequence discovery, and recovery protocols.",
    keyConcepts: [
      {
        title: 'Safe State',
        explanation: 'A state is safe if there exists a sequence <P1, P2, ... Pn> where each process can satisfy its maximum remaining resource need with currently available plus released resources.',
      },
      {
        title: 'Coffman Conditions',
        explanation: 'Four simultaneous conditions (Mutual Exclusion, Hold & Wait, No Preemption, Circular Wait) required for deadlock occurrence.',
      },
    ],
    formulas: [
      'Need[i][j] = Max[i][j] - Allocation[i][j]',
      'Safety Condition: Need[i] <= Work',
      'Updated Work: Work = Work + Allocation[i]',
    ],
    examHotspots: [
      "Numerical problem: Given Allocation and Max matrices, determine if the system is in a safe state and find the safe execution sequence (10-mark university question).",
      "List the four Coffman conditions (2-mark question).",
    ],
    suggestedQuestions: [
      "Describe Banker's Algorithm with data structures and safety check algorithm.",
      "Explain the difference between Deadlock Prevention and Deadlock Avoidance.",
    ],
  },
];

export const INITIAL_QUIZ_RESULTS: QuizResult[] = [
  {
    id: 'quiz-res-1',
    title: 'Cryptography Diagnostic Quiz 1',
    subjectId: 'subj-cs401',
    subjectName: 'Cryptography & Network Security',
    timestamp: Date.now() - 86400000 * 1.5, // 1.5 days ago
    totalQuestions: 5,
    score: 4,
    maxScore: 10,
    percentage: 40,
    weakTopics: ['RSA Euler Totient Calculation', 'RSA Public Exponent Properties'],
    masteredTopics: ['AES Block Cipher', 'Symmetric vs Asymmetric'],
    recommendationNote: 'Score 40% - High Urgency: Review RSA Key Generation modular arithmetic immediately before the upcoming exam.',
    questions: [
      {
        id: 'q-demo-1',
        type: 'mcq',
        question: 'In RSA, if p = 3 and q = 11, what is phi(n)?',
        correctAnswer: 'B. 20',
        userAnswer: 'A. 33',
        isCorrect: false,
        explanation: 'phi(n) = (p-1)*(q-1) = 2*10 = 20. Student incorrectly computed n = p*q.',
        topic: 'RSA Euler Totient Calculation',
        marks: 2,
      },
      {
        id: 'q-demo-2',
        type: 'mcq',
        question: 'What condition must public exponent e satisfy in RSA?',
        correctAnswer: 'A. 1 < e < phi(n) and gcd(e, phi(n)) = 1',
        userAnswer: 'C. e must be even',
        isCorrect: false,
        explanation: 'e must be coprime to phi(n) so its modular inverse d exists.',
        topic: 'RSA Public Exponent Properties',
        marks: 2,
      },
    ],
  },
];

export const INITIAL_RECOMMENDATION: NextActionRecommendation = {
  id: 'rec-init-1',
  headline: 'Study RSA Algorithm & Modular Math – 30 minutes',
  urgencyLevel: 'critical',
  subjectName: 'Cryptography & Network Security',
  subjectId: 'subj-cs401',
  topicTitle: 'RSA Algorithm & Modular Math',
  topicId: 'topic-rsa',
  reason: 'Your CS401 exam is in only 4 days! Your last quiz flagged RSA Key Calculation as a critical weak area (40% score). Fixing this now guarantees an easy 8-10 marks on the exam.',
  totalMinutes: 30,
  steps: [
    {
      stepNumber: 1,
      title: "Review RSA Formulas & Euler's Totient phi(n)",
      minutes: 15,
      instruction: "Read the key generation steps: n = p*q, phi(n) = (p-1)*(q-1), and ensure you understand why gcd(e, phi(n)) = 1 is mandatory.",
      completed: false,
    },
    {
      stepNumber: 2,
      title: 'Solve 3 Step-by-Step Numerical Problems',
      minutes: 10,
      instruction: 'Calculate public/private keys using sample primes p=3, q=11, e=7. Then encrypt message M=2.',
      completed: false,
    },
    {
      stepNumber: 3,
      title: 'Take a 3-Question Rapid Diagnostic Quiz',
      minutes: 5,
      instruction: 'Verify your mastery to clear the weak area alert from your dashboard.',
      completed: false,
    },
  ],
  motivationalTip: 'Commit to just 30 focused minutes right now. High-yield sprints break exam anxiety!',
  examName: 'CS401: Cryptography & Network Security Final',
  daysLeft: 4,
  generatedAt: Date.now(),
};

export const INITIAL_STATS: StudentStats = {
  streakDays: 5,
  totalMinutesStudied: 345, // ~5.75 hours
  overallReadinessPercentage: 64,
  completedTopicsCount: 8,
  totalTopicsCount: 15,
  quizzesTakenCount: 4,
  averageQuizScore: 72,
  weakTopicsCount: 2,
};
