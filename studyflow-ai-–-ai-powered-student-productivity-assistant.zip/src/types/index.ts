export type DifficultyLevel = 1 | 2 | 3 | 4 | 5;
export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';
export type AnswerFormat = 'simple' | '2-mark' | '5-mark' | '10-mark';

export interface Subject {
  id: string;
  name: string;
  code: string;
  examDate: string; // YYYY-MM-DD
  color: string;
  icon?: string;
  totalTopics: number;
  completedTopics: number;
  confidenceLevel: number; // 0-100
}

export interface Topic {
  id: string;
  subjectId: string;
  subjectName: string;
  title: string;
  summary: string;
  difficulty: DifficultyLevel;
  importance: 'high' | 'medium' | 'low';
  completed: boolean;
  mastery: number; // 0 to 100
  isWeakArea: boolean;
  lastQuizScore?: number; // 0 to 100
  estimatedMinutes: number;
  keyPoints: string[];
  calculatedPriorityScore?: number; // 0-100 derived
  priorityBadge?: PriorityLevel;
}

export interface StudyMaterial {
  id: string;
  title: string;
  subjectId: string;
  subjectName: string;
  fileName?: string;
  fileType: 'pdf' | 'notes' | 'syllabus';
  uploadDate: string;
  rawText: string;
  summary: string;
  keyConcepts: {
    title: string;
    explanation: string;
  }[];
  formulas: string[];
  examHotspots: string[];
  suggestedQuestions: string[];
}

export interface StudyPlanTask {
  id: string;
  topicId: string;
  topicTitle: string;
  subjectName: string;
  durationMinutes: number;
  timeSlot: string;
  type: 'concept' | 'practice' | 'quiz' | 'revision';
  completed: boolean;
}

export interface StudyPlanDay {
  date: string;
  dayName: string;
  isToday: boolean;
  totalHours: number;
  focusSummary: string;
  tasks: StudyPlanTask[];
}

export interface QuizQuestion {
  id: string;
  type: 'mcq' | 'descriptive';
  question: string;
  options?: string[]; // for mcq
  correctAnswer: string;
  explanation: string;
  topic: string;
  marks: number;
  userAnswer?: string;
  isCorrect?: boolean;
}

export interface QuizResult {
  id: string;
  title: string;
  subjectId: string;
  subjectName: string;
  timestamp: number;
  totalQuestions: number;
  score: number;
  maxScore: number;
  percentage: number;
  weakTopics: string[];
  masteredTopics: string[];
  questions: QuizQuestion[];
  recommendationNote: string;
}

export interface RecommendationActionStep {
  stepNumber: number;
  title: string;
  minutes: number;
  instruction: string;
  completed?: boolean;
}

export interface NextActionRecommendation {
  id: string;
  headline: string;
  urgencyLevel: 'critical' | 'high' | 'moderate';
  subjectName: string;
  subjectId: string;
  topicTitle: string;
  topicId: string;
  reason: string;
  totalMinutes: number;
  steps: RecommendationActionStep[];
  motivationalTip: string;
  examName: string;
  daysLeft: number;
  generatedAt: number;
}

export interface StudySessionLog {
  id: string;
  topicTitle: string;
  subjectName: string;
  durationMinutes: number;
  timestamp: number;
  completedStepsCount: number;
}

export interface StudentStats {
  streakDays: number;
  totalMinutesStudied: number;
  overallReadinessPercentage: number;
  completedTopicsCount: number;
  totalTopicsCount: number;
  quizzesTakenCount: number;
  averageQuizScore: number;
  weakTopicsCount: number;
}
