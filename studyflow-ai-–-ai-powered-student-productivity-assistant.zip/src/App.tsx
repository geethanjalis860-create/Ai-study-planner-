import React from 'react';
import { StudyProvider, useStudy } from './context/StudyContext';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { StudyMaterialsView } from './components/StudyMaterialsView';
import { AITutorView } from './components/AITutorView';
import { StudyPlannerView } from './components/StudyPlannerView';
import { TaskPriorityView } from './components/TaskPriorityView';
import { QuizView } from './components/QuizView';
import { ProgressView } from './components/ProgressView';
import { WhatShouldIDoNowModal } from './components/WhatShouldIDoNowModal';
import { ActiveStudySessionModal } from './components/ActiveStudySessionModal';

const AppContent: React.FC = () => {
  const { currentView } = useStudy();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header Navigation */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {currentView === 'dashboard' && <DashboardView />}
        {currentView === 'materials' && <StudyMaterialsView />}
        {currentView === 'tutor' && <AITutorView />}
        {currentView === 'planner' && <StudyPlannerView />}
        {currentView === 'priority' && <TaskPriorityView />}
        {currentView === 'quiz' && <QuizView />}
        {currentView === 'progress' && <ProgressView />}
      </main>

      {/* Flagship Modals */}
      <WhatShouldIDoNowModal />
      <ActiveStudySessionModal />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 font-medium text-slate-400">
            <span className="font-bold text-slate-300">StudyFlow AI</span> – AI-Powered Student Productivity Assistant
          </div>
          <div className="flex items-center gap-4 text-slate-500 text-[11px]">
            <span>Upload → Understand → Plan → Learn → Test → Recommend</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <StudyProvider>
      <AppContent />
    </StudyProvider>
  );
}
